		
#pragma once

#include "CommonMgd.h"

namespace ODEManaged
{	
		
void RnearCallback(void *data, dGeomID o1, dGeomID o2)
		{
		}

}




